(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_082cd387._.js",
  "static/chunks/src_acc294c4._.js",
  "static/chunks/node_modules_201d123e._.js",
  "static/chunks/node_modules_@mui_system_esm_79055653._.js",
  "static/chunks/node_modules_@mui_material_esm_1d397f30._.js",
  "static/chunks/node_modules_@popperjs_core_lib_229f7621._.js",
  "static/chunks/node_modules_9b930320._.js",
  "static/chunks/node_modules_react-quill_dist_quill_snow_df85b940.css"
],
    source: "dynamic"
});
