(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/providers/ReactQueryProvider.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ReactQueryProvider)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ReactQueryProvider({ children }) {
    _s();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "ReactQueryProvider.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]()
    }["ReactQueryProvider.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/app/providers/ReactQueryProvider.tsx",
        lineNumber: 9,
        columnNumber: 10
    }, this);
}
_s(ReactQueryProvider, "qFhNRSk+4hqflxYLL9+zYF5AcuQ=");
_c = ReactQueryProvider;
var _c;
__turbopack_context__.k.register(_c, "ReactQueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/login/LogInUser.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// zaklad učet testovaci bude john Doe "036fb56a-723c-4a07-97fe-40a173d47711" email: example@example.com
__turbopack_context__.s({
    "LogInAdmin": (()=>LogInAdmin),
    "LogInFirm": (()=>LogInFirm),
    "LogInUser": (()=>LogInUser)
});
const LogInUser = {
    id: "036fb56a-723c-4a07-97fe-40a173d47711",
    name: "John Doe",
    email: "example@example.com",
    role: "USER",
    about: ""
};
const LogInFirm = {
    id: "59b509a9-cac8-45f7-bec6-4ccb6bf775f9",
    name: "Firma s.r.o.",
    email: "firma@example.com",
    role: "FIRM",
    about: ""
};
const LogInAdmin = {
    id: "5e724726-c55c-4209-8887-4d07de5c09f8",
    name: "Admin",
    email: "admin@admin.com",
    role: "ADMIN"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "fetchApplication": (()=>fetchApplication),
    "fetchCreateApplication": (()=>fetchCreateApplication),
    "fetchCreateJob": (()=>fetchCreateJob),
    "fetchCreateUser": (()=>fetchCreateUser),
    "fetchDeleteJob": (()=>fetchDeleteJob),
    "fetchDeleteUser": (()=>fetchDeleteUser),
    "fetchUpdateJob": (()=>fetchUpdateJob),
    "fetchUpdateUser": (()=>fetchUpdateUser),
    "fetchUserByEmail": (()=>fetchUserByEmail),
    "fetchUsers": (()=>fetchUsers),
    "fetchjobs": (()=>fetchjobs)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$login$2f$LogInUser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/login/LogInUser.tsx [app-client] (ecmascript)");
;
const fetchUsers = async ()=>{
    const res = await fetch("/api/user"); // Volání našeho API
    if (!res.ok) {
        throw new Error("Failed to fetch users");
    }
    return res.json(); // Vrátíme data jako JSON
};
const fetchjobs = async ()=>{
    const res = await fetch("/api/job/getJob"); // Volání našeho API
    if (!res.ok) {
        throw new Error("Failed to fetch jobs");
    }
    return res.json(); // Vrátíme data jako JSON
};
const fetchApplication = async ()=>{
    const res = await fetch("/api/application/getApplication"); // Volání našeho API
    if (!res.ok) {
        throw new Error("Failed to fetch users");
    }
    return res.json(); // Vrátíme data jako JSON
};
const fetchUserByEmail = async (email)=>{
    const response = await fetch("/api/user/findByEmail", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email
        })
    });
    if (!response.ok) throw new Error("User not found");
    return await response.json();
};
const fetchCreateApplication = async (userid, jobid)=>{
    const response = await fetch(`/api/application/createApplication`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            userid,
            jobid
        })
    });
    console.log("response", response);
    // Check if the response is ok (status in the range 200-299)
    if (!response.ok) {
        throw new Error("Failed to update User");
    }
    const updatedJob = await response.json();
    return updatedJob;
};
const fetchCreateUser = async (updateData)=>{
    const response = await fetch(`/api/user/generateUser`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(updateData)
    });
    console.log("response", response);
    // Check if the response is ok (status in the range 200-299)
    if (!response.ok) {
        throw new Error("Failed to update User");
    }
    const User = await response.json();
    return User;
};
const fetchUpdateUser = async (id, updateData)=>{
    const response = await fetch(`/api/user/editUser/${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(updateData)
    });
    console.log("response", response);
    // Check if the response is ok (status in the range 200-299)
    if (!response.ok) {
        throw new Error("Failed to update User");
    }
    const updatedJob = await response.json();
    return updatedJob;
};
const fetchCreateJob = async (jobData)=>{
    const response = await fetch("/api/job/addJob", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(jobData)
    });
    if (!response.ok) {
        throw new Error("Failed to create job");
    }
    return await response.json();
};
const fetchDeleteUser = async (userid)=>{
    try {
        const res = await fetch(`/api/user/deleteUser/${userid}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || "Failed to delete");
        }
        const deleted = await res.json();
        console.log("Deleted:", deleted);
    } catch (err) {
        console.error("Error deleting job:", err);
    }
};
const fetchDeleteJob = async (jobId)=>{
    try {
        const res = await fetch(`/api/job/deleteJob/${jobId}`, {
            method: "DELETE",
            headers: {
                "x-company-id": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$login$2f$LogInUser$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogInFirm"]?.id || ""
            }
        });
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || "Failed to delete");
        }
        const deleted = await res.json();
        console.log("Deleted:", deleted);
    } catch (err) {
        console.error("Error deleting job:", err);
    }
};
const fetchUpdateJob = async (jobId, updateData)=>{
    const response = await fetch(`/api/job/editJob/${jobId}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(updateData)
    });
    console.log("response", response);
    // Check if the response is ok (status in the range 200-299)
    if (!response.ok) {
        throw new Error("Failed to update job");
    }
    const updatedJob = await response.json();
    return updatedJob;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/store/useAppStore.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// store/useAppStore.ts
__turbopack_context__.s({
    "useAppStore": (()=>useAppStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
;
;
;
const useAppStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set, get)=>({
        users: {},
        jobs: {},
        applications: {},
        LogIn: null,
        selectedJobId: null,
        selectedUserId: null,
        selectedUserData: null,
        filteredJobs: [],
        setFilteredJobs: (jobs)=>set({
                filteredJobs: jobs
            }),
        setSelectedUserId: (id)=>set({
                selectedUserId: id
            }),
        setSelectedJobId: (id)=>set({
                selectedJobId: id
            }),
        setSelectedUserData: (user)=>set({
                selectedUserData: user
            }),
        setApplications: (applications)=>{
            const applicationMap = applications.reduce((acc, application)=>{
                acc[application.id] = application;
                return acc;
            }, {});
            set({
                applications: applicationMap
            });
        },
        setLogIn: (user)=>set({
                LogIn: user
            }),
        setUsers: (users)=>{
            const userMap = users.reduce((acc, user)=>{
                acc[user.id] = user;
                return acc;
            }, {});
            set({
                users: userMap
            });
        },
        setJobs: (jobs)=>{
            const jobMap = jobs.reduce((acc, job)=>{
                acc[job.id] = job;
                return acc;
            }, {});
            set({
                jobs: jobMap
            });
        },
        getUserById: (id)=>{
            return get().users[id];
        },
        getJobById: (id)=>{
            return get().jobs[id];
        },
        getApplicationById: (id)=>{
            return get().applications[id];
        },
        fetchAndSetUsers: async (email)=>{
            const selectedUserData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchUserByEmail"])(email);
            set({
                selectedUserData
            }); // nebo jak ukládáš uživatele do store
        }
    }), {
    name: "app-storage"
}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/AppQuerryProvider.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$useAppStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/useAppStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const AppDataFetcher = ()=>{
    _s();
    const { setJobs, setUsers, setApplications } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$useAppStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])();
    const { data: jobs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "jobs"
        ],
        queryFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchjobs"]
    });
    const { data: users } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "users"
        ],
        queryFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchUsers"]
    });
    const { data: applications } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "applications"
        ],
        queryFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchApplication"]
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppDataFetcher.useEffect": ()=>{
            if (jobs) setJobs(jobs);
            if (users) setUsers(users);
            if (applications) setApplications(applications);
        }
    }["AppDataFetcher.useEffect"], [
        jobs,
        users,
        applications
    ]);
    return null; // nic nevykresluje, jen fetchuje a ukládá
};
_s(AppDataFetcher, "zUVpf4kVbltGnm+IUk5vW5w3fFE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$useAppStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = AppDataFetcher;
const __TURBOPACK__default__export__ = AppDataFetcher;
var _c;
__turbopack_context__.k.register(_c, "AppDataFetcher");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_9c13d7da._.js.map