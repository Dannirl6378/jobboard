(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_dompurify_dist_purify_es_mjs_39224456._.js",
  "static/chunks/node_modules_dompurify_dist_purify_es_mjs_ffc8196b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/dompurify/dist/purify.es.mjs [app-client] (ecmascript)");
    });
});
}}),
"[project]/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_2414eaf4._.js",
  "static/chunks/node_modules_react-quill-new_lib_index_252107d3.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);